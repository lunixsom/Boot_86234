/*
  ========= Ejercicio 2: Operaciones básicas =========
  
  Crear dos variables numéricas. Y asignarles cualquier valor. Por ejemplo: numero1 = 10; numero2 = 5;
  Calcular y mostrar por consola:

  - La suma
  - La resta
  - La multiplicación
  - La división
  - El módulo (resto de la división)

  Resultado esperado:

  Suma: 15
  Resta: 5
  Multiplicación: 50
  División: 2

  Realizar pruebas con diferentes valores para las variables numéricas y comprobar que los resultados son correctos.
*/
const n1 = 10;
const n2 = 5;

console.log("Suma:", n1 + n2);
console.log("Resta:", n1 - n2);
console.log("Multiplicación:", n1 * n2);
console.log("División:", n1 / n2);
console.log("Módulo:", n1 % n2);