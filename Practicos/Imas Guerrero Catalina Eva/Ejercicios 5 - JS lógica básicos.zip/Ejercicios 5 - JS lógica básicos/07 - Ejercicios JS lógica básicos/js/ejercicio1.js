/* 
  ========= Ejercicio 1: Saludo personalizado =========
  Crear una variable llamada `nombre` y otra variable llamada `edad`.
  Mostrar por consola un mensaje como el siguiente:

    Hola, mi nombre es Martín y tengo 29 años.

*/
let nombre = "Martín";
let edad = 29;

console.log(`Hola, mi nombre es ${nombre} y tengo ${edad} años.`);