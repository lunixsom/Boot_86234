/*
  Ejercicio 14: Sistema de descuentos por categoría
  ===================================================
  Crear dos variables: `categoria` (string) y `precioOriginal` (number).

  Aplicar el descuento según la categoría del producto:
    - "electronica" → 10% de descuento
    - "ropa"        → 20% de descuento
    - "alimentos"   → 5% de descuento
    - Otra categoría → 0% de descuento

  const categoria = "ropa";
  const precioOriginal = 5000;

  Resultado esperado:
    Categoría: ropa
    Descuento: 20%
    Precio final: 4000

  Requisitos técnicos:
    - Usar switch / case para seleccionar el porcentaje de descuento
    - Guardar el porcentaje en una variable `descuento`
    - Calcular el `precioFinal` fuera del switch
    - Mostrar los tres valores con template literals
*/

const categoria = "ropa";
const precioOriginal = 5000;
let precioFinal;

console.log(`Categoria : ${categoria}`);

switch(categoria){
  case "electronica" :
    console.log("Descuento: 10%");
    precioFinal = precioOriginal * 0.90;
    break;

  case "ropa":
    console.log("Descuento: 20%");
    precioFinal = precioOriginal * 0.80;
    break;

  case "alimentos" :
    console.log("Descuento: 5%");
    precioFinal = precioOriginal * 0.95;
    break;

  default : 
    console.log("Sin descuento");
};

console.log(`Precio final: ${precioFinal}`);

