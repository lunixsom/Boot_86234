/*
  Ejercicio 4: Semáforo
  ======================
  Crear una variable llamada `colorSemaforo` con uno de estos valores posibles:
  "rojo", "amarillo", "verde".

  Mostrar la instrucción correspondiente:
    - "rojo"     → "Detener"
    - "amarillo" → "Precaución"
    - "verde"    → "Avanzar"
    - Otro valor → "Color inválido"

  const colorSemaforo = "verde";

  Resultado esperado:
    Avanzar

  Requisitos técnicos:
    - Usar switch / case con un default
    - No usar if / else en este ejercicio
*/

const colorSemáforo = "rojo";

switch(colorSemáforo){
  case "verde" : 
    console.log("Avanzar");
    break;
  
  case "amarillo" :
    console.log("Ir frenando");
    break;

  case "rojo" : 
    console.log("Frenar");
    break;

  default : 
    console.log("El color no corresponde a un color del semáforo");
}