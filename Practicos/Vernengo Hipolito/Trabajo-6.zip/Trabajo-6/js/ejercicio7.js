/*
  Ejercicio 7: Número entre rango
  =================================
  Pedir al usuario que ingrese un número y almacenarlo en una variable `numero`.
  Crear dos variables:  `minimo` y `maximo`.

  Verificar si `numero` está dentro del rango [minimo, maximo]
  (inclusive en ambos extremos).

  
  const minimo = 40;
  const maximo = 100;

  Ejemplo el usuario ingresa 15:

  Resultado esperado:
    El número 15 no está dentro del rango.

  Requisitos técnicos:
    - Usar && para verificar ambas condiciones al mismo tiempo
    - La condición es: numero >= minimo && numero <= maximo
    - Usar template literal para incluir el número en el mensaje
*/

const numero = +prompt("Ingresa un número");
const maximo = 100;
const minimo = 40;

if(numero >= 40 && numero <= 100){
  console.log(`El número ${numero} se encuentra dentro del rango`);
} else{
  console.log(`El número ${numero} no se encuentra dentro del rango`);
}
