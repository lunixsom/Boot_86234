
/*
  Ejercicio 13: Calculadora de envío
  =====================================
  Variables de base:
    const totalCompra = 45000;
    const esClientePremium = true;
    const pesoEnvio = 3;

  Calcular el costo de envío según estas reglas:
    - Si el cliente es premium                          → envío gratis
    - Si no es premium y la compra supera 50000         → envío gratis
    - Si no es premium y el peso es mayor a 5 kg        → "Envío: $2000"
    - En cualquier otro caso                            → "Envío: $800"

  Mostrar el resultado por consola.

  Requisitos técnicos:
    - Evaluar las condiciones en el orden correcto (de más específica a más general)
    - Usar && y || según corresponda
    - Usar template literal en los mensajes con costo
*/

const totalCompra = 45000;
const esPremium = false;
const pesoEnvio = 6;

if(esPremium){
  console.log("Envío gratis");
}else if(totalCompra > 50000){
  console.log("Envío gratis");
}else if(pesoEnvio > 5){
  console.log(`Usted cuenta con ${pesoEnvio}kg, este supera el limite de 5kg. Costo de envío: $2000`);
}else {
  console.log("Envio: $800");
};
